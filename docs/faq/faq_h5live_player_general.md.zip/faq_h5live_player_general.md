---
id: faq_h5live_player_general
title: General
sidebar_label: General
---

<details><summary><strong>Which browsers/plattforms do we support??</strong></summary>

The low-latency nanoStream h5Live Player runs on all full-featured HTML5 browsers including

- Safari 10,11,12 on iOS and macOS
- Chrome 54 and higher on desktop and mobile
- Firefox 48 and higher
- Edge
- Internet Explorer 11 (starting Windows 8.1)

For Internet Explorer 11 on Windows 7, H5Live player contains a Flash player fallback for RTMP.

</details>


